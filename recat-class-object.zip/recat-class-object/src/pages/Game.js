import React, { useState } from 'react'



 const Game = () => {

      const [list, setlist] = useState(['1','2','3','4','5','6','7','8','9']);
      const [Next, setNext] = useState(true);
      const [winner, setWinner] = useState(""); 
   
  


        const btn = (i,v) => {

          var d = [...list];
          
         

         
      };
    
   

  return (

   <>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 50px)', gap: '10px', height:'100px' }}>
    
          <input type='button' value={list[0]} onClick={(e) => {btn(0, e.target.value)}} />
          <input type='button' value={list[1]} onClick={(e) => {btn(1, e.target.value)}} />
          <input type='button' value={list[2]} onClick={(e) => {btn(2, e.target.value)}} />
          <input type='button' value={list[3]} onClick={(e) => {btn(3, e.target.value)}} />
          <input type='button' value={list[4]} onClick={(e) => {btn(4, e.target.value)}} />
          <input type='button' value={list[5]} onClick={(e) => {btn(5, e.target.value)}} />
          <input type='button' value={list[6]} onClick={(e) => {btn(6, e.target.value)}} />
          <input type='button' value={list[7]} onClick={(e) => {btn(7, e.target.value)}} />
          <input type='button' value={list[8]} onClick={(e) => {btn(8, e.target.value)}} />


  </div>

    </>
  )
}



export default Game;



