import React, { useState } from 'react';

const Tictac = () => {
    const [cell1, setCell1] = useState(null);
    const [cell2, setCell2] = useState(null);
    const [cell3, setCell3] = useState(null);
    const [cell4, setCell4] = useState(null);
    const [cell5, setCell5] = useState(null);
    const [cell6, setCell6] = useState(null);
    const [cell7, setCell7] = useState(null);
    const [cell8, setCell8] = useState(null);
    const [cell9, setCell9] = useState(null);
    const [isXNext, setIsXNext] = useState(true);
    const [winner, setWinner] = useState("");

    const btn = (setCell, cellValue) => {
        if (cellValue || winner) return; 

        setCell(isXNext ? 'X' : 'O'); 
        setIsXNext(!isXNext);

        checkWinner(); 
    };

    const checkWinner = () => {
        const winConditions = [
            [cell1, cell2, cell3],
            [cell4, cell5, cell6],
            [cell7, cell8, cell9],
            [cell1, cell4, cell7],
            [cell2, cell5, cell8],
            [cell3, cell6, cell9],
            [cell1, cell5, cell9],
            [cell3, cell5, cell7],
        ];

        for (let condition of winConditions) {
            const [a, b, c] = condition;
            if (a && a === b && a === c) {
                setWinner(a);
                return;
            }
        }
         if (cell1 && cell2 && cell3 && cell4 && cell5 && cell6 && cell7 && cell8 && cell9) {
            setWinner("Draw");
        }
    };

    const resetGame = () => {
        setCell1(null);
        setCell2(null);
        setCell3(null);
        setCell4(null);
        setCell5(null);
        setCell6(null);
        setCell7(null);
        setCell8(null);
        setCell9(null);
        setWinner("");
        setIsXNext(true);
    };

    return (
        <div>
            <h2>{winner ? `Winner: ${winner}` : `Next Player: ${isXNext ? 'X' : 'O'}`}</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 50px)', gap: '10px', height:'100px' }}>
                <button onClick={() => btn(setCell1, cell1)}>{cell1}</button>
                <button onClick={() => btn(setCell2, cell2)}>{cell2}</button>
                <button onClick={() => btn(setCell3, cell3)}>{cell3}</button>
                <button onClick={() => btn(setCell4, cell4)}>{cell4}</button>
                <button onClick={() => btn(setCell5, cell5)}>{cell5}</button>
                <button onClick={() => btn(setCell6, cell6)}>{cell6}</button>
                <button onClick={() => btn(setCell7, cell7)}>{cell7}</button>
                <button onClick={() => btn(setCell8, cell8)}>{cell8}</button>
                <button onClick={() => btn(setCell9, cell9)}>{cell9}</button>
            </div>
            <button onClick={resetGame}>Reset Game</button>
        </div>
    );
}

export default Tictac;