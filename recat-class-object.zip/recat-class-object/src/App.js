import logo from './logo.svg';
import './App.css';
import Footer from './pages/Footer';
import TodoList from './pages/Todolist';
import Header from './pages/Header';
import Game from './pages/Game';
import Tictac from './pages/Tictac';
import Puzzle from './pages/Puzzle';




function App() {


  return (
    <>
     
  
    <Game/>


    </>
  );
}

export default App;
